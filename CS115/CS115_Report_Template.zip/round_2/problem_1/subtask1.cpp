#include <bits/stdc++.h>
using namespace std;
 
const int N = 4004;
const int md = (int)1e9 + 7;
 
void add(int& a, int b) {
	a += b;
	if(a >= md)
		a -= md;
}
 
int n, min_suf[N];
char s[N], t[N];
 
int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cin >> n >> s;
	memcpy(t, s, n * sizeof *s);
 
	int tot = count(s, s + n, 'x');
	int res = 0;
 
	for(int mask = 1<<tot; mask--; ) {
		for(int i = 0, cnt = 0; i < n; ++i)
			if(s[i] == 'x') {
				t[i] = (mask >> cnt & 1) ? '(' : ')';
				++cnt;
			}
 
		int sum = 0;
		for(int i = 0; i < n; ++i)
			sum += (t[i] == '(') ? 1 : -1;
 
		min_suf[n] = 0;
		for(int i = n - 1; i >= 0; --i)
			min_suf[i] = min(0, min_suf[i + 1] + (t[i] == '(' ? 1 : -1));
 
		for(int l = 0, pref = 0; l < n; ++l) {
			int sumlr = 0, maxlr = 0;
			for(int r = l; r < n; ++r) {
				// check sum[0 .. l-1] - sum[l..r] + sum[r+1..n-1] = 0
				//   =>  sum[0 .. l-1] + sum[l..r] + sum[r+1 .. n-1] = 2sum[l..r] = sum[0..n-1]
				sumlr += (t[r] == '(') ? 1 : -1;
				maxlr = max(maxlr, sumlr);
				if(2 * sumlr != sum)
					continue;
				if(pref - maxlr >= 0 && pref - sumlr + min_suf[r + 1] >= 0)
					++res;
			}
			pref += (t[l] == '(') ? 1 : -1;
			if(pref < 0)
				break;
		}
	}
 
	cout << res;
	return 0;
}

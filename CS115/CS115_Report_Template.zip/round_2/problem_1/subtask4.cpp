#include <bits/stdc++.h>
using namespace std;
 
const int N = 4004;
const int md = (int)1e9 + 7;
 
void add(int& a, int b) {
	a += b;
	if(a >= md)
		a -= md;
}
 
int n;
char s[N];
 
int dp[N][N][3];
 
int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cin >> n >> s;
	dp[0][0][0] = dp[0][0][1] = 1;
	for(int i = 0; i < n; ++i) {
		for(int j = 0, mx = min(i, n>>1); j <= mx; ++j) {
			for(int t = 0; t < 3; ++t) {
				int ft = dp[i][j][t];
				if(ft == 0)
					continue;
				for(int val = -1; val <= 1; val += 2) {
					if((s[i] == '(' && val == -1) || (s[i] == ')' && val == 1))
						continue;
					int cur = (t == 1) ? -val : val;
					if(j + cur < 0)
						continue;
					add(dp[i + 1][j + cur][t], ft);
					if(t < 2)
						add(dp[i + 1][j + cur][t + 1], ft);
				}
			}
		}
	}
	cout << dp[n][0][2];
	return 0;
}

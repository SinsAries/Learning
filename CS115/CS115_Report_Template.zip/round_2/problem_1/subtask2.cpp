#include <bits/stdc++.h>
using namespace std;
 
const int N = 103;
const int md = (int)1e9 + 7;
 
void add(int& a, int b) {
	a += b;
	if(a >= md)
		a -= md;
}
 
int n, dp[N][N];
char s[N];
 
int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	cin >> n >> s;
	int res = 0;
	for(int l = 0; l < n; ++l) {
		for(int r = l; r < n; ++r) {
			memset(dp[0], 0, (n + 1) * sizeof *dp[0]);
			dp[0][0] = 1;
			for(int i = 0; i < n; ++i) {
				memset(dp[i + 1], 0, (n + 1) * sizeof *dp[i + 1]);
				for(int j = 0, mx = min(i, n>>1); j <= mx; ++j) {
					int ft = dp[i][j];
					if(ft == 0)
						continue;
					for(int val = -1; val <= 1; val += 2) {
						if((s[i] == '(' && val == -1) || (s[i] == ')' && val == 1))
							continue;
						int cur = (l <= i && i <= r) ? -val : val;
						if(j + cur < 0)
							continue;
						add(dp[i + 1][j + cur], ft);
					}
				}
			}
			add(res, dp[n][0]);
		}
	}
	cout << res;
	return 0;
}

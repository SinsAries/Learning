#include <bits/stdc++.h>
using namespace std;

int n, x[22], y[22];
long long ans;
void backtrack(int i, int rMin, int rMax, int bMin, int bMax) {
    if (i > n) {
        ans = min(ans, 1ll * (rMax - rMin) * (bMax - bMin));
        return;
    }

    backtrack(i + 1, min(rMin, x[i]), max(rMax, x[i]), min(bMin, y[i]), max(bMax, y[i]));
    backtrack(i + 1, min(rMin, y[i]), max(rMax, y[i]), min(bMin, x[i]), max(bMax, x[i]));
}

int main() {
    cin >> n;

    for (int i = 1; i <= n; ++i)
        cin >> x[i] >> y[i];

    ans = LLONG_MAX;
    backtrack(1, INT_MAX, -1, INT_MAX, -1);

    cout << ans;
}
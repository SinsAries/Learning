#include <bits/stdc++.h>
using namespace std;

const int MAX_N = 200005;

int n, x[MAX_N], y[MAX_N];
pair<int, int> ball[MAX_N * 2];

bool enough(int rMinId, int rMaxId) {
    int rMin = ball[rMinId].first, rMax = ball[rMaxId].first;
    for (int i = 1; i <= n; ++i)
        if (!((rMin <= x[i] && x[i] <= rMax) || (rMin <= y[i] && y[i] <= rMax)))
            return false;
    return true;
}

pair<int, int> newBall[MAX_N * 2];
int exited[MAX_N];
long long getAns(int rMinId, int rMaxId) {
    int rMin = ball[rMinId].first, rMax = ball[rMaxId].first;

    int sizeBall = 0;
    for (int i = 1; i <= n; ++i) {
        if (rMin <= x[i] && x[i] <= rMax && rMin <= y[i] && y[i] <= rMax) {
            newBall[++sizeBall] = {x[i], i};
            newBall[++sizeBall] = {y[i], i};
        } else if (rMin <= x[i] && x[i] <= rMax)
            newBall[++sizeBall] = {y[i], i};
        else if (rMin <= y[i] && y[i] <= rMax)
            newBall[++sizeBall] = {x[i], i};
    }

    sort(newBall + 1, newBall + sizeBall + 1);
    int j = 0, countBag = 0;
    long long res = LLONG_MAX;
    fill(exited + 1, exited + n + 1, 0);

    for (int i = 1; i <= sizeBall; ++i) {
        while (j < sizeBall && countBag < n) {
            ++j;
            if (!exited[newBall[j].second])
                ++countBag;
            ++exited[newBall[j].second];
        }

        if (countBag < n)
            break;

        int bMin = newBall[i].first, bMax = newBall[j].first;

        res = min(res, 1ll * (rMax - rMin) * (bMax - bMin));

        --exited[newBall[i].second];
        if (!exited[newBall[i].second])
            --countBag;
    }

    return res;
}

int main() {
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> x[i] >> y[i];
        ball[i] = {x[i], i};
        ball[i + n] = {y[i], i};
    }

    sort(ball + 1, ball + 2 * n + 1);

    long long ans = LLONG_MAX;

    for (int i = 1; i < 2 * n; ++i)
        for (int j = i + 1; j <= 2 * n; ++j)
            if (ball[i].second != ball[j].second && enough(i, j))
                ans = min(ans, getAns(i, j));
    cout << ans;
}

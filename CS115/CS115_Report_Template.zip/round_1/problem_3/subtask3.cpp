#include<bits/stdc++.h>
#define newl '\n'

const int N = 1e5 + 10;
const int B = 18;
const int V = 1e6 + 10;
const long long M = 1e9 + 7;
const long long INF = 1e18;

struct Node{
    long long s;
    Node *l,*r;
    Node(int s) : s(s),l(nullptr),r(nullptr){

    }
    Node(Node *ll,Node *rr) : l(ll),r(rr){
        assert(ll && rr);
        s = l->s + r->s;
    }
};
typedef Node* pNode;
struct PersistentST{
    std::vector<pNode> root;
    PersistentST(){
        root.emplace_back(new Node(0));
        root.back()->l = root.back();
        root.back()->r = root.back();
    }
private:
    pNode update(int l,int r,int pos,int val,pNode t){
        if(l == r){
            return new Node(t->s + val);
        }
        int mid = (l + r) / 2;
        if(pos <= mid){
            return new Node(update(l,mid,pos,val,t->l),t->r);
        }
        return new Node(t->l,update(mid + 1,r,pos,val,t->r));
    }
    long long query(int l,int r,int u,int v,pNode vL,pNode vR){
        if(u <= l && r <= v){
            return vR->s - vL->s;
        }
        int mid = (l + r) / 2;
        if(v <= mid){
            return query(l,mid,u,v,vL->l,vR->l);
        }
        if(u > mid){
            return query(mid + 1,r,u,v,vL->r,vR->r);
        }
        return query(l,mid,u,v,vL->l,vR->l) + query(mid + 1,r,u,v,vL->r,vR->r);
    }
public:
    void update(int l,int r,int pos,int val,int verL,int verR){
        assert(verR <= (int)root.size());
        if(verR == (int)root.size()){
            root.emplace_back(update(l,r,pos,val,root[verL]));
        }else{
            root[verR] = update(l,r,pos,val,root[verL]);
        }
    }
    void copyRoot(int ver){
        root.emplace_back(root[ver]);
    }
    long long query(int l,int r,int u,int v,int vL,int vR){
        return query(l,r,u,v,root[vL - 1],root[vR]);
    }
};

int par[N + 1][B + 1],in[N + 1],out[N + 1],n,q,t,m,timer = 0;
long long f[N + 1][8],a[N + 1],ans = 0;
std::vector<int> adj[N + 1];

void readData(){
    std::cin >> n >> q >> t >> m;
    for(int i = 2;i <= n;++i){
        int u,v;
        std::cin >> u >> v;
        adj[u].emplace_back(v);
        adj[v].emplace_back(u);
    }
}
void dfs(int u = 1){
    in[u] = ++timer;
    for(int v : adj[u]){
        if(v == par[u][0]){
            continue;
        }
        par[v][0] = u;
        dfs(v);
    }
    out[u] = timer;
}
void precompute(){
    par[1][0] = 1;
    for(int j = 1;j <= B;++j){
        for(int i = 1;i <= n;++i){
            par[i][j] = par[par[i][j - 1]][j - 1];
        }
    }
}
bool ancestor(int u,int v){
    return (in[u] <= in[v] && out[u] >= out[v]);
}
int lca(int u,int v){
    if(ancestor(u,v)){
        return u;
    }
    if(ancestor(v,u)){
        return v;
    }
    for(int i = B;i >= 0;--i){
        if(!ancestor(par[u][i],v)){
            u = par[u][i];
        }
    }
    return par[u][0];
}
void dfs1(int u = 1){
//    if(u == 10){
//        std::cerr << "STOP\n";
//    }
    for(int v : adj[u]){
        if(v == par[u][0]){
            continue;
        }
        dfs1(v);
        for(int j = 0;j <= m;++j){
            ans = std::max(ans,f[u][j] + f[v][m - j]);
        }
        for(int j = 0;j <= m;++j){
            f[u][j] = std::max(f[u][j],f[v][j]);
        }
    }
    for(int j = m;j >= 1;--j){
        f[u][j] = f[u][j - 1] + a[u];
    }
}
void solve(){
    PersistentST st;
    for(int i = 1;i <= q;++i){
        auto update = [&](int u,int v,int w) -> void{
            int l = lca(u,v);
            st.copyRoot(i - 1);
            st.update(1,n,in[u],w,i,i);
            st.update(1,n,in[v],w,i,i);
            st.update(1,n,in[l],-w * 2,i,i);
        };
        int u,v,w;
        std::cin >> u >> v >> w;
        update(u,v,w);
    }
    for(int i = 1;i <= t;++i){
        int l,r;
        std::cin >> l >> r;
        for(int i = 1;i <= n;++i){
            a[i] = st.query(1,n,in[i],out[i],l,r);
        }
        for(int i = 1;i <= n;++i){
            for(int j = 0;j <= m;++j){
                f[i][j] = 0;
            }
        }
        dfs1();
        std::cout << ans << newl;
        ans = 0;
    }
}
int main(){
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    freopen("qtree.inp","r",stdin);
    freopen("qtree.out","w",stdout);
    readData();
    dfs();
    precompute();
    solve();
    return 0;
}


///breaker
#pragma GCC optimize("O3")
#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define ii pair<int,int>
#define mp make_pair
#define in(x) freopen(x,"r",stdin)
#define out(x) freopen(x,"w",stdout)
#define bit(x,i) ((x>>i)&1)
#define lc (id<<1)
#define rc ((id<<1)^1)
const int maxn=1e5+7;
const ll inf=1e18+7;
struct query
{
    int u,v,val;
};
query qu[5*maxn];
vector<int>adj[maxn];
int in[maxn];
int out[maxn];
int sz[maxn];
ll con[maxn];
int cnt=0;
void dfs(int u,int par)
{
    in[u]=++cnt;
    sz[u]=1;
    for(int v:adj[u])if(v!=par){
        dfs(v,u);
        sz[u]+=sz[v];
    }
    out[u]=++cnt;
}
int n,q,t,m;
ll dp[maxn][10];
void dfs1(int u,int par)
{
    for(int v:adj[u])if(v!=par){
        dfs1(v,u);
        for(int i=min(sz[u]-1,m);i>=0;i--){
            for(int j=0;j<min(sz[v],m+1);j++){
                if(i>=j+1)dp[u][i]=max(dp[u][i],dp[u][i-j-1]+dp[v][j]+con[v]);
            }
        }
    }
}
void sol(void){
    cin>>n>>q>>t>>m;
    for(int i=1;i<n;i++){
        int u,v;
        cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    dfs(1,0);
    for(int i=1;i<=q;i++){
        cin>>qu[i].u>>qu[i].v>>qu[i].val;
    }
    while(t--){
        int l,r;
        cin>>l>>r;
        for(int i=1;i<=n;i++){
            con[i]=0;
            for(int j=1;j<=m;j++){
                dp[i][j]=-inf;
            }
            dp[i][0]=0;
        }
        for(int i=l;i<=r;i++){
            int u=qu[i].u;
            int v=qu[i].v;
            if(in[u]<in[v]){
                con[v]+=qu[i].val;
            }
            else{
                con[u]+=qu[i].val;
            }
        }
        dfs1(1,0);
        ll res=-inf;
        for(int i=1;i<=n;i++){
            res=max(res,dp[i][m]);
        }
        cout<<res<<"\n";
    }
}
signed main(void)
{
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    if(fopen("qtree.inp","r")){
        freopen("qtree.inp","r",stdin);
        freopen("qtree.out","w",stdout);
    }
    sol();
    return 0;
}


#include <bits/stdc++.h>
using namespace std;

#define int ll
#define N  500010
#define ll long long
#define fs first
#define sc second
#define ii pair<int,int>
#define pb push_back
#define iii pair<int,pair<int,int>>
#define ld long double
#define getbit(x,y) ((x>>y)&1)
#define matrix vector<vector<ll>>
#define getid(x,y) (x*2-1-y)
#define S 500001

int dp[N][10],labels[N],a[N],n,q,t ,m, times, LOG = 0, cha[N][21];
vector<int> g[N];
ii cnt[N];

void DFS(int u,int p)
{
    cnt[u].fs=++times;
    for(auto v:g[u])
        if(v!=p)
        {
            cha[v][0]=u;
            DFS(v,u);
        }
    cnt[u].sc=times;
}

bool ascentor(int u,int v)
{
    return (cnt[u].fs<=cnt[v].fs&&cnt[u].sc>=cnt[v].sc);
}

int lca(int u,int v)
{
    if(ascentor(u,v))
        return u;
    if(ascentor(v,u))
        return v;
    for(int k=LOG;k>=0;k--)
        if(cha[u][k]!=0 && !ascentor(cha[u][k],v))
            u=cha[u][k];
    return cha[u][0];
}

struct query
{
    int u,v,k,r;
}query[N];

bool SS(const int&u,const int&v)
{
    return cnt[u].fs<=cnt[v].fs;
}

void process(int u)
{
    dp[u][0]=0;
    for(auto v:g[u])
        if(cha[u][0]!=v)
        {
            //cout<<u<<" "<<v<<" "<<a[v]<<endl;
            process(v);
            for(int i=m;i>=1;i--)
                for(int j=0;j<i;j++)
                    dp[u][i]=max(dp[u][i],dp[u][i-j-1]+dp[v][j]+a[v]);
        }
}

void solve()
{
    memset(a,0,sizeof(a));
    memset(dp,-0x3f3f,sizeof(dp));
    int l,r;
    cin>>l>>r;
    for(int i=l;i<=r;i++)
    {
        a[query[i].u]+=query[i].k;
        a[query[i].v]+=query[i].k;
        a[query[i].r]-=(query[i].k*2);
    }
    for(int i=n;i>=1;i--)
    {
        int u=labels[i];
        for(auto v:g[u])
            if(cha[u][0]!=v)
                a[u]+=a[v];
    }
    process(1);
    int ans=0;
    for(int i=1;i<=n;i++)
        ans=max(ans,dp[i][m]);
    cout<<ans<<"\n";
}

int32_t main()
{
    freopen("QTREE.inp", "r", stdin);
    freopen("QTREE.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(NULL);
    cout.tie(NULL);
        cin >> n>>q>>t>>m;
        for(int i=1;i<n;i++)
        {
            int u,v;
            cin>>u>>v;
            g[u].pb(v);
            g[v].pb(u);
        }

    DFS(1,0);
    LOG=log2(n);
    for(int k=1;k<=LOG;k++)
        for(int i=1;i<=n;i++)
            cha[i][k]=cha[cha[i][k-1]][k-1];
    for(int i=1;i<=q;i++)
    {
        int u,v,k;
        cin>>u>>v>>k;
        int r=lca(u,v);
        query[i]={u,v,k,r};
    }
    for(int i=1;i<=n;i++)
        labels[i]=i;
    sort(labels+1,labels+1+n,SS);
    while(t--)
        solve();
    return 0;
}

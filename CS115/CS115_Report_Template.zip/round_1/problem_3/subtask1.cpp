#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define fi first
#define se second
#define pb push_back
#define ii pair<int, int>
#define iii pair<int, pair<int, int> >
#define MASK(i) ((1LL) << (i))
#define BIT(x, i) (((x) >> (i)) & (1LL))
using namespace std;

template<class T> bool maximize(T& a, const T& b) {
    return a < b ? a = b, 1 : 0;
}

template<class T> bool minimize(T& a, const T& b) {
    return a > b ? a = b, 1 : 0;
}

const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
const int mod = 1e9 + 7;
const ll N = 5e5 + 5;
const ll inf = 1e9;

int n, q, t, m, depth[N], par[20];
vector<pair<int, int>> adj[N];
pair<pair<int, int>, int> queries[N];
pair<int, int> edges[20];
int w[20][20];
bool vis[20];

void dfs(int u, int Par){
    for (pair<int, int> p : adj[u]) if (p.fi != Par){
        par[p.fi] = u;
        depth[p.fi] = depth[u] + 1;
        dfs(p.fi, u);
    }
}

int dfs2(int u, int par, int mask){
    int res = 0;
    for (pair<int, int> p : adj[u]) if (BIT(mask, p.se - 1) && p.fi != par){
        res += w[p.fi][u] + dfs2(p.fi, u, mask);

    }
    return res;
}

#define TASK "qtree"
int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(NULL); cout.tie(NULL);
    if(fopen(TASK".inp", "r")){
        freopen(TASK".INP", "r", stdin);
        freopen(TASK".OUT", "w", stdout);
    }

    cin >> n >> q >> t >> m;
    for (int i = 1; i < n; i++){
        int u, v;
        cin >> u >> v;
        edges[i] = {u, v};
        adj[u].pb({v, i});
        adj[v].pb({u, i});
    }
    for (int i = 1; i <= q; i++){
        int u, v, k;
        cin >> u >> v >> k;
        queries[i] = {{u, v}, k};
    }
    dfs(1, 0);
    while(t--){
        int l, r;
        cin >> l >> r;
        memset(w, 0, sizeof w);
        for (int i = l; i <= r; i++){
            int u = queries[i].fi.fi, v = queries[i].fi.se, k = queries[i].se;
            if (depth[u] < depth[v]) swap(u, v);
            while(depth[u] > depth[v]){
                w[u][par[u]] += k;
                u = par[u];
            }
            while(u != v){
                w[u][par[u]] += k;
                w[par[u]][u] += k;
                w[v][par[v]] += k;
                w[par[v]][v] += k;
                u = par[u];
                v = par[v];
            }
        }
        int res = 0;
        for (int mask = 0; mask < MASK(n - 1); mask++){
            if (__builtin_popcount(mask) > m) continue;
            for (int i = 1; i <= n; i++) vis[i] = 0;
            for (int i = 1; i <= n; i++){
                maximize(res, dfs2(i, 0, mask));
            }
        }
        cout << res << '\n';
    }
    return 0;   
}

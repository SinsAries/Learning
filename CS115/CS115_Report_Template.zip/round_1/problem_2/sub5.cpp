#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 5;
int n, a[N], k, l[N];

void solve() {
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    int res = 0;
    for (int i = 1; i <= n; i++) {
        int r = 0, j;
        for (j = i; j > 0; j--) {
            if (!l[a[j]]) {
                r++;
            }
            if (r > k + 1) {
                break;
            }
            l[a[j]]++;
            res = max(res, l[a[j]]);
        }
        for (int h = j + 1; h <= i; h++) {
            l[a[h]] = 0;
        }
    }
    cout << res << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    solve();
}
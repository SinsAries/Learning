#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 5;
int n, a[N], k, l[N], res = 0;
vector < int > s;

void cal(int i, int z) {
    if (i == s.size()) {
        int pre = 0, ans = 0, d = 0;
        for (int j = 1; j <= n; j++) {
            if (!l[a[j]]) {
                if (a[j] == pre) {
                    d++;
                }
                else {
                    ans = max(ans, d);
                    d = 1;
                    pre = a[j];
                }
            }
        }
        ans = max(ans, d);
        res = max(res, ans);
        return;
    }
    cal(i + 1, z);
    if (z < k) {
        l[s[i]] = 1;
        cal(i + 1, z + 1);
        l[s[i]] = 0;
    }
}

void solve() {
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        s.push_back(a[i]);
    }
    sort(s.begin(), s.end());
    s.resize(distance(s.begin(), unique(s.begin(), s.end())));
    cal(0, 0);
    cout << res;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    solve();
}
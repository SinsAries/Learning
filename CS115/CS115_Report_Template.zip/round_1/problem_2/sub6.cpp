#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 5;
int n, a[N], k, p[N], f[N][70], last[N];

void solve() {
    vector < int > s;
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        s.push_back(a[i]);
    }
    sort(s.begin(), s.end());
    s.resize(distance(s.begin(), unique(s.begin(), s.end())));
    for (int i = 0; i < s.size(); i++) {
        p[s[i]] = i;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < s.size(); j++) {
            f[i][j] = f[i - 1][j];
        }
        f[i][p[a[i]]]++;
    }
    k = min(k, (int)s.size() - 1);
    int res = 0;
    for (int i = 1; i <= n; i++) {
        last[p[a[i]]] = i;
        vector < int > g;
        g.push_back(0);
        for (int j = 0; j < s.size(); j++) {
            g.push_back(last[j]);
        }
        sort(g.begin(), g.end(), greater < int > ());
        int u = g[k + 1];
        for (int j = 0; j < s.size(); j++) {
            res = max(res, f[i][j] - f[u][j]);
        }
    }
    cout << res;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    solve();
}
#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 5;
int n, a[N], k;

void solve() {
    vector < int > s;
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        s.push_back(a[i]);
    }
    sort(s.begin(), s.end());
    s.resize(distance(s.begin(), unique(s.begin(), s.end())));
    int res = 0;
    for (int i = 0; i < s.size(); i++) {
        for (int j = 0; j < s.size(); j++) {
            int pre = 0, ans = 0, d = 0;
            for (int k = 1; k <= n; k++) {
                if (a[k] != s[i] && a[k] != s[j]) {
                    if (a[k] == pre) {
                        d++;
                    }
                    else {
                        ans = max(ans, d);
                        d = 1;
                        pre = a[k];
                    }
                }
            }
            ans = max(ans, d);
            res = max(res, ans);
        }
    }
    cout << res;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    solve();
}
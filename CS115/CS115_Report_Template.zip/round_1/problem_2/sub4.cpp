//problem "sub1"
//created in 16:45:38 - Thu 12/09/2024
#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 5;
int n, a[N], k, l[N];

void solve() {
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    int res = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            int ans = 0, r = 0;
            for (int h = j; h <= i; h++) {
                if (!l[a[h]]) {
                    r++;
                }
                l[a[h]]++;
                ans = max(ans, l[a[h]]);
            }
            if (r <= k + 1) {
                res = max(res, ans);
            }
            for (int h = j; h <= i; h++) {
                l[a[h]] = 0;
            }
        }
    }
    cout << res << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    solve();
}
#include<bits/stdc++.h>
#define fi first
#define se second
#define nmax 131078
using namespace std;

typedef pair<int, int> pii;

int n, k, ans, cnt[1028], a[nmax];
multiset<int, greater<int> >f;

void update(int x, int val = 1) {
    if (cnt[x] != 0) {
        f.erase(f.find(cnt[x]));
    }
    if ((cnt[x] += val) != 0) {
        f.insert(cnt[x]);
    }
}

void solve() {
    ans = 0;
    memset(cnt, 0, sizeof(cnt));
    cin >> n >> k;
    
    for (int j = 0, i = 0; i <= n; i++) {
        cin >> a[i];
        update(a[i]);
        while (f.size() > k + 1) {
            update(a[j++], -1);
        }
        ans = max(ans, *f.begin());
    }

    cout << ans;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    solve();
}
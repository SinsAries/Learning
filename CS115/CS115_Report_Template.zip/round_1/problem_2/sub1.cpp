#include<bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;
int n, a[N], k;

void solve() {
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    int res = 0;
    for (int i = 1; i <= n; i++) {
        int ans = 0, d = 0, pre = 0;
        for (int j = 1; j <= n; j++) {
            if (a[j] == a[i]) {
                continue;
            }
            if (a[j] == pre) {
                d++;
            }
            else {
                ans = max(ans, d);
                d = 1;
                pre = a[j];
            }
        }
        ans = max(ans, d);
        res = max(res, ans);
    }
    cout << res;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    solve();
}
#include <bits/stdc++.h>
using namespace std;
 
const int md = (int)1e9 + 7;
const int N = (int)2e5 + 10;
 
int a[N];
 
int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	int n, m;
	cin >> n >> m;
	for(int i = 1; i <= n; ++i)
		cin >> a[i];
	long long res = 0;
	while(m--) {
		int u, v;
		cin >> u >> v;
		res += a[u] + a[v];
	}
	res %= md;
	for(int i = 3; i <= n; ++i)
		res = (res * i) % md;
	cout << res;
	return 0;
}

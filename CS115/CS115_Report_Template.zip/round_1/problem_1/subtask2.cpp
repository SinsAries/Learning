#include <bits/stdc++.h>
using namespace std;
 
const int md = (int)1e9 + 7;
void add(int& a, int b) {
	a += b;
	if(a >= md)
		a -= md;
}
#define mul(a, b) ((long long)(a) * (b) % md)
 
const int N = 20;
 
int a[N], adj[N], f[N];
int sum[1 << N], dp[1 << N];
 
int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
 
	int n, m;
	cin >> n >> m;
	assert(n <= 20);
	for(int i = 0; i < n; ++i)
		cin >> a[i];
	memset(adj, 0, n * sizeof *adj);
	while(m--) {
		int u, v;
		cin >> u >> v;
		--u, --v;
		adj[u] |= 1 << v;
		adj[v] |= 1 << u;
	}
 
	f[0] = 1;
	for(int i = 1; i < n; ++i)
		f[i] = mul(f[i - 1], i);
 
	sum[0] = 0;
	for(int i = 1, u, v; i < (1<<n); ++i) {
		u = i & (i - 1);
		v = i ^ u;
		sum[i] = sum[u];
		add(sum[i], a[__builtin_ctz(v)]);
	}
 
	dp[0] = 0;
	for(int t = 0; t < (1<<n) - 1; ++t) {
		int ft = dp[t];
		int way = f[__builtin_popcount(t)];
		for(int i = 0; i < n; ++i) {
			if(t >> i & 1)
				continue;
			add(dp[t | (1<<i)], ft);
			add(dp[t | (1<<i)], mul(way, sum[ ~t & adj[i] ]));
		}
	}
	cout << dp[(1 << n) - 1];
	return 0;
}

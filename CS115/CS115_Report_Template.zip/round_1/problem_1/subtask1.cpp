#include <bits/stdc++.h>
using namespace std;
 
const int md = (int)1e9 + 7;
void add(int& a, int b) {
	a += b;
	if(a >= md)
		a -= md;
}
 
const int N = (int)2e5 + 10;
int a[N], sum[N], adj[N];
 
int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
 
	int n, m;
	cin >> n >> m;
	for(int i = 0; i < n; ++i)
		cin >> a[i];
	while(m--) {
		int u, v;
		cin >> u >> v;
		--u, --v;
		adj[u] |= 1 << v;
		adj[v] |= 1 << u;
	}
	sum[0] = 0;
	for(int i = 1, u, v; i < (1<<n); ++i) {
		u = i & (i - 1);
		v = i ^ u;
		sum[i] = sum[u];
		add(sum[i], a[__builtin_ctz(v)]);
	}
	vector<int> p(n);
	iota(p.begin(), p.end(), 0);
	int res = 0;
	do {
		int used = 0;
		for(int i : p) {
			used |= 1 << i;
			add(res, sum[ ~used & adj[i] ]);
		}
	} while(next_permutation(p.begin(), p.end()));
	cout << res;
	return 0;
}
